[L1,L2,L3,L4,L5,L6,mu] = linkLengths ();

theta1 = 60*pi/180;
theta2 = -30*pi/180;
theta_body = 0*pi/180;

q1 =  pi/2 - theta1; 
q2 =  pi/2 - theta2;

B1 = [-L5/2*cos(theta_body) - L1*cos(q1) ; -L5/2*sin(theta_body) - L1*sin(q1)];
B2 = [L5/2*cos(theta_body) + L2*cos(pi-q2) ; L5/2*sin(theta_body) - L2*sin(pi-q2)];

a = abs(B1(1) - B2(1));
b =  B1(2) - B2(2);
B12 = sqrt(a^2 + b^2);

if b<=0.0
    %% Knee angle
    alpha = atan2(b,a);
    beta = acos( ((L4)^2 - (B12)^2 - (L3)^2)/(-2*(B12)*(L3)) );
    q3 = alpha + beta;

    %% Angle between virtual leg and knee
    c = sqrt(L3^2 + L6^2 - 2*L3*L6*cos(mu)); % virtual leg
    lamda = asin(L6*(sin(mu)/c));
    
    X_foot = 0.5*L5 + L2*cos(pi-q2) - c*cos(q3+lamda);
    Y_foot = L2*sin(pi-q2) + c*sin(q3+lamda);
