%% NOTE: Increase Kp [2;6;10] to show increased accuracy
figure()
plot(X_foot_check,Y_foot_check,'.')
axis('equal');