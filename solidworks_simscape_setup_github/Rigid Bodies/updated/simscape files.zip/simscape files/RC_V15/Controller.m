function [B,ctrl_state,polarPosition,tau]  = Controller(motors,InitConstants,bodyState,theta_ML,theta_MR,dtheta_ML,dtheta_MR)
    
    x_body = bodyState.x;
    dx_body = bodyState.dx;
    y_body = bodyState.y;
    dy_body = bodyState.dy;

    startButton = InitConstants.startButton;
    alternate_legs = InitConstants.alternate_legs;
    control_type = InitConstants.control_type;
    dx_des = InitConstants.dx_des;
    x_des = InitConstants.x_des;
    
    r_des = InitConstants.r_des;
    phi_des = InitConstants.phi_des;
    dr_des = InitConstants.dr_des;
    dphi_des = InitConstants.dphi_des;
    Kpr_des = InitConstants.Kpr_des;
    Kdr_des = InitConstants.Kdr_des;
    Kpphi_des = InitConstants.Kpphi_des;
    Kdphi_des = InitConstants.Kdphi_des;

    if motors == 23
    
        r_ref = InitConstants.r_d_23;
        phi_ref = InitConstants.phi_d_23;
        dr_ref = InitConstants.dr_d_23;
        dphi_ref = InitConstants.dphi_d_23;
        F_push = InitConstants.Fpush_d_23;
    
        Kp_r = InitConstants.Kp_r_d_23;  
        Kd_r = InitConstants.Kd_r_d_23;
        Kp_phi = InitConstants.Kp_phi_d_23;
        Kd_phi  = InitConstants.Kd_phi_d_23; 
        r_thrust = InitConstants.rthrust_d_23;
        GAIN_dx = InitConstants.GAIN_dx_d_23;

    else % 14
        r_ref = InitConstants.r_d_14;
        phi_ref = InitConstants.phi_d_14;
        dr_ref = InitConstants.dr_d_14;
        dphi_ref = InitConstants.dphi_d_14;
        F_push = InitConstants.Fpush_d_14;
    
        Kp_r = InitConstants.Kp_r_d_14;  
        Kd_r = InitConstants.Kd_r_d_14;
        Kp_phi = InitConstants.Kp_phi_d_14;
        Kd_phi  = InitConstants.Kd_phi_d_14; 
        r_thrust = InitConstants.rthrust_d_14;
        GAIN_dx = InitConstants.GAIN_dx_d_14;
    end

    [JT11,JT12,JT21,JT22] = Jacobian_Transpose(theta_ML,theta_MR);
    [r,phi,dr,dphi] = ConvertToPolar(theta_ML,theta_MR,dtheta_ML,dtheta_MR);
    polarPosition = [r;phi];
    JT = [JT11,JT12;JT21,JT22];

    y_foot = r*cos(phi); % +ve value
    
    % constants
    phi_neutral = phi_ref;
    r0 = r_ref; % 0.38 0.33
    r_min = r_thrust; % 0.30 0.25
    dt = 0.02;
    
    F_thrust = 0;
    tau = 0;

    persistent state
    persistent phi0
    persistent contact_offset
    persistent Ts
    persistent stance_timer

    if startButton == 0
        % 0 = Rest
        state = State.Thrust;
        w = [0;0];
        B = JT*w;

    elseif startButton == 1
        % 1 = Impedence control
        state = State.Thrust;
        E = [r_des - r; phi_des - phi];
        dE = [dr_des - dr; dphi_des - dphi];
        wr = Kpr_des*E(1) + Kdr_des*dE(1);
        wphi = Kpphi_des*E(2) + Kdphi_des*dE(2);
        w = [wr;wphi];
        B = JT*w;

    elseif startButton == 2
        % 2 = Hop
        state = State.Thrust;
        if (r > r0)
            F_thrust = 0;
        else
            F_thrust = F_push;
        end       
        Fr = Kp_r*(r_ref - r) + Kd_r*(dr_ref - dr) + F_thrust;
        B = JT * [Fr; tau];

    else
        % 3 = Raibert Control
        if isempty(state)
            state = State.Thrust;
        end
        if isempty(phi0)
            phi0 = phi_neutral;
        end
        if isempty(contact_offset)
            contact_offset = 0;
        end
        if isempty(Ts)
            Ts = 0.175;
        end
        if isempty(stance_timer)
            stance_timer = 0;
        end 
    
        % calculate foot contact
        foot_height = y_body - y_foot; %- contact_offset; % This gets the foot height distance %- contact_offset;
        if (foot_height > 0.005)
            foot_contact = false;
        else
            foot_contact = true;
        end
        
        % update stance duration
        if foot_contact
            stance_timer = stance_timer + dt;
        end
        
       % (1 = Flight, 2 = Loading, 3 = Compression, 4 = Thrust, 5 = Unloading)
        % state transitions
        if state == State.Flight
            if control_type == 0
                dx_des = 0.0;
            elseif control_type == 1
                dx_des = InitConstants.dx_des;
            elseif control_type == 2
                dx_des = -min(max(1.0*(x_body - x_des), -0.5), 0.5);
            end
            
            x_foot = 0.5*dx_body*0.175 + GAIN_dx*(dx_body - dx_des);
            phi0 = phi_neutral + asin(x_foot / r0);
            tau = Kp_phi*(phi0 - phi) + Kd_phi*(0 - dphi); % position foot
    
            if foot_contact
                state = State.Loading;
            end
        
        elseif state == State.Loading
            if (dr < 0)
                state = State.Compression;
            end
        
        elseif state == State.Compression
            % leg velocity isn't always exactly zero
            if ((-0.1 < dr && dr < 0.1) && (r < r_min))
                state = State.Thrust;
                contact_offset = y_body - y_foot; % update foot contact offset
            end
       
        elseif state == State.Thrust
            F_thrust = F_push;
            if (r > r0)
                state = State.Unloading;
            end
        
        elseif state == State.Unloading
            if not(foot_contact)
                state = State.Flight;
                Ts = min(stance_timer, 0.28); % record stance time
                stance_timer = 0; % reset stance timer
            end
        end
            
        % permanent radial spring damper
        Fr = Kp_r*(r_ref - r) + Kd_r*(dr_ref - dr) + F_thrust;
        
        % transform into joint torques
        B = JT * [Fr; tau];       
        
    end
    ctrl_state = state;
    
end