forcePlateMass = 90/9.81

SS_body = 5756.78;
SS_UL = 153.81;
SS_LR = 499.95;
SS_LL = 346.45;

SS_mass = (SS_body + 4*SS_UL + 2*SS_LR + 2*SS_LL)/1000
