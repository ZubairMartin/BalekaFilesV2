% Setup files
AK90_10_initBusObjects
AK90_10_parameters
initialization
initBusObjects
parameters
setup
testScript