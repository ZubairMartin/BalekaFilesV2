%% Visual
Boom.Base.color = [1.0 1.0 1.0 1.0]; % RGBA
Boom.Center.color = [1.0 1.0 1.0 1.0]; % RGBA
Boom.Pole.color = [1.0 1.0 1.0 1.0]; % RGBA
Boom.End.color = [1.0 1.0 1.0 1.0]; % RGBA
